// Simple preload script
console.log('Preload script loaded successfully');
